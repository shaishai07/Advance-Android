# Advanced android in kotlin
 
